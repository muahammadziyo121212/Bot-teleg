# 🎬 PREMIUM KINO BOT

Telegram orqali kino va seriallarni unikal kod bilan tarqatuvchi professional bot.

**Stack:** Python 3.11+ · aiogram 3.x · **SQLite / Turso (libSQL)** · APScheduler

> TZ da PostgreSQL ko'rsatilgan edi — bu loyihada **SQLite** ishlatilgan.
> Bitta kod ikki muhitda ishlaydi: lokalda oddiy fayl, bulutda **Turso**
> (bepul, doimiy). Bulutga joylash: **[DEPLOY.md](DEPLOY.md)**.

---

## 🚀 Ishga tushirish

```bash
# 1. Virtual muhit (allaqachon yaratilgan)
.venv\Scripts\activate

# 2. Kutubxonalar (allaqachon o'rnatilgan)
pip install -r requirements.txt

# 3. Sozlamalar — .env faylini tahrirlang
#    BOT_TOKEN, MAIN_ADMIN_ID, ADMIN_PASSWORD

# 4. Ishga tushirish
python bot.py
```

Jadvallar **birinchi ishga tushganda avtomatik** yaratiladi. Lokalda baza =
bitta `kinoBaza.db` fayli. Bulutga (Render + Turso, bepul) joylash uchun:
**[DEPLOY.md](DEPLOY.md)**.

## 📋 Birinchi qadamlar

1. `/admin` → parol (`090704`)
2. **📡 Kanal sozlamalari** → **📦 Baza kanal** qo'shing (botni kanalda admin qiling!)
3. **🎬 Kino sozlamalari** → **➕ Kino qo'shish**
4. Foydalanuvchi `10000` kodini yuboradi → kino keladi ✅

---

## ⚡ Tezlik va trafik tejash yechimlari

Bot 12 000+ foydalanuvchiga mo'ljallangan. Qo'llanilgan yechimlar:

### 1. Video hech qachon qayta yuklanmaydi
Kontent baza kanaldan `copy_message` bilan ko'chiriladi — bu Telegram serveri
ichidagi amal, fayl bot orqali **o'tmaydi**. Zaxira: `file_id`.
→ *2 GB lik kino ham 0 bayt trafik, deyarli bir zumda.*

### 2. Obuna tekshiruvi — 3 qatlamli kesh
Eng qimmat amal: har kanal uchun alohida `get_chat_member` so'rovi.

| Qatlam | Nima qiladi |
|--------|-------------|
| `_pass_cache` | To'liq o'tgan foydalanuvchi TTL davomida **umuman** tekshirilmaydi |
| `_member_cache` | Har (user, kanal) juftligi alohida — faqat **yetishmayotgani** so'raladi |
| `chat_member` hodisasi | Kanaldan chiqsa — kesh **shu zahoti** bekor bo'ladi |

→ *Obuna bo'lgan foydalanuvchi uchun API so'rovlari: **0 ta**.*
→ *Uchinchi qatlam tufayli uzoq TTL (10 daq) xavfsiz: chiqib ketgan odam
   TTL ni kutmasdan, keyingi harakatidayoq obuna panelini ko'radi.*

### 3. Yozuv buferlari
Ko'rishlar va `last_seen` har harakatda diskka yozilmaydi — xotirada yig'ilib,
30 sekundda **bitta tranzaksiyada** tashlanadi.
→ *Sekundiga yuzlab yozuv o'rniga 30 sekundda 1 ta.* Bot to'xtaganda ham saqlanadi.

### 4. Issiq ma'lumot xotirada
Adminlar, kanallar, sozlamalar — startda yuklanadi, o'zgarganda bekor qilinadi.
→ *Har update'da `is_admin()` tekshiruvi = **dict lookup**, DB'ga bormaydi.*
Kontent uchun LRU kesh (1024 ta kod).

### 5. libSQL — lokal ham, bulut ham bitta kod
Baza qatlami `libsql-client` ustida: URL `file:...` bo'lsa lokal SQLite fayl,
`libsql://...` bo'lsa **Turso** (bulut, doimiy). Kodni o'zgartirmasdan muhit
almashtiriladi (`.env` orqali). Yozuvlar bitta `batch` (tranzaksiya) bilan
atomik, kod generatsiyasi `RETURNING` bilan poyga-shartsiz.

Remote Turso bo'lsa ham tez ishlaydi: yuqoridagi kesh qatlami tufayli
foydalanuvchi harakatlarining ko'pi bazaga umuman bormaydi, shuning uchun
tarmoq kechikishi sezilmaydi.

### 6. Broadcast dvigateli
- **Keyset pagination** — 12 000 ID RAM'ga yig'ilmaydi, oqim sifatida o'qiladi
- **Worker pool** (12 ta) — tarmoq kutishi ustma-ust tushadi
- **Global token bucket** — sekundiga aniq 25 xabar (`sleep(0.05)` dan aniqroq:
  parallel worker'lar birgalikda ham limitdan oshmaydi)
- `TelegramRetryAfter` → kutadi va **qayta urinadi** (xabar yo'qolmaydi)
- Bloklaganlar avtomatik `status='blocked'` bo'ladi → keyingi broadcast ularga urinmaydi
- Hisobot har 3 sekundda yangilanadi (har xabarda emas)

### 7. Boshqa
- Panellar `edit_message` bilan yangilanadi — qayta yuborilmaydi
- Serial sahifasi almashganda faqat **klaviatura** edit qilinadi
- Kontent o'chirishda `delete_messages` — 100 xabar **bitta so'rovda**
- Obuna tekshiruvida kanallar **parallel** (`asyncio.gather`)
- `bot.me()` keshlanadi — username uchun har safar API'ga borilmaydi

---

## 📁 Struktura

```
bot.py                  # ishga tushirish, scheduler, router tartibi
config.py               # .env
database/
  db.py                 # SQLite dvigatel (WAL, pul, sxema)
  queries.py            # CRUD + keshlar + buferlar
handlers/
  user/                 # start, obuna, kontent
  admin/                # panel, statistika, kontent, kanallar, adminlar,
                        # broadcast, bildirishnoma
keyboards/              # user_kb, admin_kb
states/                 # FSM
middlewares/            # ban_check, subscription
utils/                  # texts (premium UI), helpers, cache,
                        # broadcaster, filters
```

**Router tartibi muhim:** admin routerlari birinchi ulanadi, aks holda
foydalanuvchi qismidagi «raqam emas» to'sig'i admin tugmalarini ushlab qolardi.

---

## 🔐 Xavfsizlik

- `.env` — `.gitignore` da, hech qachon commit qilinmaydi
- Parol xabari darhol o'chiriladi (chatda qolmaydi)
- 3 marta xato parol → 5 daqiqa blok
- Admin bo'lmaganga `/admin` → `❌ Noma'lum buyruq` (panel oshkor bo'lmaydi)
- Asosiy adminni o'chirib bo'lmaydi, admin o'zini o'chira olmaydi

---

## ⚙️ Ixtiyoriy sozlamalar (`.env`)

| Kalit | Vazifasi |
|-------|----------|
| `AUTO_APPROVE` | Zayavka so'rovini bot avtomatik tasdiqlaydi |
| `PROTECT_CONTENT` | Kinoni forward/saqlashdan himoya qiladi |
| `SUB_CACHE_TTL` | Obuna keshi muddati (soniya, default 600) |
# qaysikinobot
